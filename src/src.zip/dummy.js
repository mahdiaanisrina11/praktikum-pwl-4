export const data = [
    {   "_id": "1",
        "name": "Sucker Punch",
        "genres": ["Action", "Advanture", "Fantasy"],
        "image": "https://m.media-amazon.com/images/M/MV5BNDEwNGRlNjQtZjI4OC00ZmMxLWEyYmQtNGI1NDk4YmUyYTNkXkEyXkFqcGdeQXVyNjQ2MjQ5NzM@._V1_.jpg",
        "description": "Sucker Punch is a movie starring Emily Browning, Vanessa Hudgens, and Abbie Cornish. A young girl institutionalized by her abusive stepfather retreats to an alternative reality as a coping strategy and envisions a plan to help her...",
        "datePublished": "2011-03-24"
    }
]